Compilation of Abeetles:

Requirements:
*Library Qt must be installed at standard location
*MinGW compilator must be installed at standard location
*Boost library must be installed at standard location

Add MinGW and Qt paths to system:
set Path=%Path%C:\Qt\4.3.0\bin\;C:\MinGW\bin\;


Compilation:
*In this directory command: qmake
*In this directory command: mingw32-make