#pragma once

class CRunLife
{
public:
	CRunLife(void);
	~CRunLife(void);
	static int run(void);
};
