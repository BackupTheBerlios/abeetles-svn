#include "StdAfx.h"
#include "CfgManager.h"
#include "defines.h"
#include "Beetle.h"
#include "Environment.h"
#include <string.h>


CfgManager::CfgManager(void)
{
}

CfgManager::~CfgManager(void)
{
}

// reads init content of environment from files Env_cfg.bmp and AdamBeetles.txt
bool CfgManager::GetGridInit(int Grid [20][20][2]/*3D array*/, int FirstIndex,int Width, int Height)
{

	//instead of reading of files is here for the timebeing this: Empty environment with 1 beetle in top right corner

	int I,J,K;
	//init all Grid.. include borders!
	for (I=0;I< (FirstIndex+Width+1);I++)
		for (J=0;J< (FirstIndex+Height+1);J++)
			for (K=0;K<2;K++)
				Grid[I][J][K]=0;
	


	char BrainExample[2][4][4][4];
	BrainExample[NOT_HUNGRY][NOTHING][NOTHING][NOTHING]=A_STEP;
	CBeetle * beetle=new CBeetle(50,SOUTH,25,(char[2][4][4][4])BrainExample);

	FILE * btlFile;
	errno_t err;
	if ((err= fopen_s(&btlFile,"Beetle.txt","r"))!=0) 
		printf("%d",err);

	I=1;
	while (!feof(btlFile))
	{
		LoadNextBeetle(btlFile,beetle);
		Grid[I][1][0]=BEETLE;
		Grid[I][1][1]=(int)beetle;
		I++;
	}
	fclose(btlFile);

	
	return true;
}

int CfgManager::LoadBeetleCfgFile(void)
{
	char VarName[25];
	int VarValue=0;
	errno_t err;
	int I;
	FILE * pConfigFile;
	if ((err= fopen_s(&pConfigFile,"BeetleCfg.txt","r"))!=0) 
		return err;
	for (I=0;I<NUMOPTVARIABLES;I++)
	{
		fscanf_s(pConfigFile,"%s=%d\n",VarName,&VarValue);
		if ( strcmp(VarName,"EnergyMax_C") == 0) CBeetle::EnergyMax_C=VarValue;
		else CBeetle::EnergyMax_C=50;

	}
	return 0;
}

bool CfgManager::GetGridShape(int * G_FirstIndex,int * G_Width, int * G_Height)
{
	*G_FirstIndex=1;
	*G_Width = 15;
	*G_Height =15;
	return true;
}

bool CfgManager::GetOptionsInit(void)
{
	//proprietary solution
	CBeetle::EnergyMax_C=50;
	//later: LoadBeetleCfgFile();
	return true;
}

bool CfgManager::LoadNextBeetle(FILE * file, //file opened for reading
																CBeetle* beetle)
{
	char  VarName[20];
	int VarValue=0;
	int I;
		
	//reading of file using fscanf_s function
	/*remarks:
		1.One white-space character in the format matches any number (including 0) and combination of white-space characters in the input.
	*/
		fscanf_s(file," ---------- ");
    fscanf_s(file," Age = %d ; ",&VarValue);
    beetle->Age=VarValue;
    fscanf_s(file," Brain = ");
    for (I=0;I<127;I++)
    {
      fscanf(file," %d ,",&VarValue);
      beetle->SetBrain(I,VarValue);
    }
    fscanf(file," %d ; ",&VarValue);
    beetle->SetBrain(127,VarValue);
    fscanf_s(file," Direction = %d ; ",&VarValue);
    beetle->Direction=VarValue;
    fscanf_s(file," Energy = %d ; ",&VarValue);
    beetle->Energy=VarValue;
    fscanf_s(file," ExpectOnPartner = ");
    for (I=0;I<4;I++)
    {
      fscanf(file," %d , ",&VarValue);
      beetle->ExpectOnPartner[I][0]=VarValue;
      fscanf(file," %d ; ",&VarValue);
      beetle->ExpectOnPartner[I][1]=VarValue;
    }
    fscanf_s(file," HungryThreshold = %d ; ",&VarValue);
    beetle->HungryThreshold=VarValue;
    fscanf_s(file," InvInChild = %d ; ",&VarValue);
    beetle->InvInChild=VarValue;
    fscanf_s(file," LearnAbility = %d ; ",&VarValue);
    beetle->LearnAbility=VarValue;

		fscanf_s(file," ---------- ");
	
	return true;
}
